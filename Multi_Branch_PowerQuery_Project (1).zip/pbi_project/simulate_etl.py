"""
Simulates, in pandas, the exact same cleaning/merge logic written in the
Power Query M code (Power_Query_M_Code/01_Master_Query_CombineAllBranches.pq).

This produces Cleaned_Output/Fact_Sales_Consolidated.xlsx so the project has
a concrete "before -> after" proof-of-work, even without opening Power BI
Desktop. When you build the real .pbix, the M queries should produce an
identical table to this one.
"""
import pandas as pd

SRC = "/home/claude/pbi_project/Source_Data"
OUT = "/home/claude/pbi_project/Cleaned_Output"

# ---------------------------------------------------------------
# LAHORE — skip 2 title rows, promote headers, rename to standard schema
# ---------------------------------------------------------------
lahore = pd.read_excel(f"{SRC}/branch_lahore.xlsx", sheet_name="Sales", skiprows=3)
lahore = lahore.rename(columns={
    "Date": "SaleDate", "ProductID": "SKU", "ProductName": "Product",
    "Units Sold": "QtySold", "Unit Price": "UnitPrice", "Total Sales": "LineTotal",
})
lahore["SaleDate"] = pd.to_datetime(lahore["SaleDate"])
lahore["Branch"] = "Lahore"

# ---------------------------------------------------------------
# KARACHI — fix DD/MM/YYYY text date, strip "Rs " prefix from price
# ---------------------------------------------------------------
karachi = pd.read_excel(f"{SRC}/branch_karachi.xlsx", sheet_name="RawExport")
karachi["Sale_Date"] = pd.to_datetime(karachi["Sale_Date"], format="%d/%m/%Y")
karachi["Price(Rs)"] = karachi["Price(Rs)"].astype(str).str.replace("Rs", "", regex=False).str.strip().astype(float)
karachi = karachi.rename(columns={
    "Sale_Date": "SaleDate", "Item_Code": "SKU", "Item_Name": "Product",
    "Cat": "Category", "Qty": "QtySold", "Price(Rs)": "UnitPrice", "Revenue": "LineTotal",
})
karachi["Branch"] = "Karachi"

# ---------------------------------------------------------------
# ISLAMABAD — drop blank spacer rows, fill missing Category, derive missing UnitPrice
# ---------------------------------------------------------------
islamabad = pd.read_excel(f"{SRC}/branch_islamabad.xlsx", sheet_name="Data")
islamabad = islamabad.dropna(subset=["SKU"]).copy()
islamabad["Category"] = islamabad["Category"].fillna("Unknown")
islamabad["UnitPrice"] = islamabad.apply(
    lambda r: r["LineTotal"] / r["QtySold"] if pd.isna(r["UnitPrice"]) else r["UnitPrice"], axis=1
)
islamabad = islamabad.rename(columns={"TransactionDate": "SaleDate"})
islamabad["SaleDate"] = pd.to_datetime(islamabad["SaleDate"])
islamabad["Branch"] = "Islamabad"

# ---------------------------------------------------------------
# PESHAWAR — unpivot wide month columns, reattach unit price via lookup
# ---------------------------------------------------------------
peshawar_raw = pd.read_excel(f"{SRC}/branch_peshawar.xlsx", sheet_name="MonthlyUnits")
month_cols = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
core_cols = ["SKU", "Product", "Category"]
peshawar_core = peshawar_raw[core_cols + month_cols]
peshawar_long = peshawar_core.melt(id_vars=core_cols, value_vars=month_cols,
                                    var_name="Month", value_name="QtySold")
month_map = {m: i + 1 for i, m in enumerate(month_cols)}
peshawar_long["SaleDate"] = pd.to_datetime(
    "2025-" + peshawar_long["Month"].map(month_map).astype(str) + "-01"
)
price_lookup = {"SKU-101":1200,"SKU-102":3500,"SKU-103":4200,"SKU-104":2800,
                 "SKU-105":5600,"SKU-106":950,"SKU-107":8900,"SKU-108":1600}
peshawar_long["UnitPrice"] = peshawar_long["SKU"].map(price_lookup)
peshawar_long["LineTotal"] = peshawar_long["QtySold"] * peshawar_long["UnitPrice"]
peshawar_long["Branch"] = "Peshawar"
peshawar_long = peshawar_long.drop(columns=["Month"])

# ---------------------------------------------------------------
# COMBINE ALL 4 BRANCHES
# ---------------------------------------------------------------
COLS = ["SaleDate", "SKU", "Product", "Category", "QtySold", "UnitPrice", "LineTotal", "Branch"]
combined = pd.concat([lahore[COLS], karachi[COLS], islamabad[COLS], peshawar_long[COLS]],
                      ignore_index=True)
combined = combined.drop_duplicates().sort_values("SaleDate").reset_index(drop=True)
combined.insert(0, "SalesID", range(1, len(combined) + 1))

combined.to_excel(f"{OUT}/Fact_Sales_Consolidated.xlsx", index=False, sheet_name="Fact_Sales")

# ---------------------------------------------------------------
# Quick data-quality + summary printout for the README
# ---------------------------------------------------------------
print("Total consolidated rows:", len(combined))
print("Missing UnitPrice rows (should be 0):", combined["UnitPrice"].isna().sum())
print("\nBranch-wise totals:")
print(combined.groupby("Branch")["LineTotal"].sum().round(0))
print("\nCategory-wise totals:")
print(combined.groupby("Category")["LineTotal"].sum().sort_values(ascending=False).round(0))
