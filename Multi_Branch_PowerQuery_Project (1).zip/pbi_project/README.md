# Multi-Branch Retail Sales Consolidation | Power Query (M) + Power BI

Consolidates 4 real-world-style, **differently formatted** branch sales exports
into one clean fact table using **Power Query / M language**, then models it
into a star schema for Power BI reporting.

This project was built specifically to demonstrate **Power Query, M language,
and ETL/data-warehousing skills** — the messy source files were designed to
mirror problems analysts hit constantly in real jobs: inconsistent headers,
text-formatted dates, currency symbols stored as text, blank rows, missing
values, and pivoted (wide-format) exports that need unpivoting.

---

## 1. Business Problem

A retail company has 4 branches (Lahore, Karachi, Islamabad, Peshawar). Each
branch exports its own sales data from a different POS system, so every file
has a different structure. Management wants **one consolidated dashboard**
showing sales trends, branch performance, and category performance — but the
raw files can't be combined as-is.

## 2. The Messy Source Data (`/Source_Data`)

| File | Format problem |
|---|---|
| `branch_lahore.xlsx` | 2 title rows above the real header; needs `Table.Skip` |
| `branch_karachi.xlsx` | Date stored as **text** in `DD/MM/YYYY`; price stored as text with `"Rs "` prefix |
| `branch_islamabad.xlsx` | Random **blank spacer rows**; ~10% missing `Category`; ~15% missing `UnitPrice` |
| `branch_peshawar.xlsx` | **Wide/pivoted** format — months as columns instead of rows; needs `Unpivot` |

## 3. What Power Query Does (`/Power_Query_M_Code`)

| Query | Key M functions used |
|---|---|
| `01_Master_Query_CombineAllBranches.pq` | `Table.Skip`, `Table.PromoteHeaders`, `Date.FromText`, `Text.Replace`/`Number.From` (currency-text cleanup), `Table.SelectRows` (blank-row removal), `Table.ReplaceValue` (fill missing category), conditional column (derive missing price), `Table.UnpivotOtherColumns`, `Table.NestedJoin`, `Table.Combine`, `Table.Distinct` |
| `02_Dim_Date.pq` | `List.Dates` calendar table generator |
| `03_Dim_Product.pq` | Distinct product list, referenced (not duplicated) from the fact query |

Open any `.pq` file and paste it straight into **Power BI Desktop → Home →
Transform Data → Advanced Editor** (update the folder path first).

## 4. Star Schema Data Model

```
        Dim_Date                    Dim_Product
      ┌──────────────┐            ┌──────────────┐
      │ SaleDate (PK)│            │ SKU (PK)     │
      │ Year         │            │ Product      │
      │ MonthName    │            │ Category     │
      │ Quarter      │            └──────┬───────┘
      │ WeekOfYear   │                   │
      └──────┬───────┘                   │
             │        1        *         │
             └────────────┬──────────────┘
                           │
                     Fact_Sales
              ┌───────────────────────┐
              │ SalesID (PK)          │
              │ SaleDate (FK)         │
              │ SKU (FK)              │
              │ QtySold               │
              │ UnitPrice             │
              │ LineTotal             │
              │ Branch                │
              └───────────────────────┘
```

`Dim_Date[SaleDate]` marked as the model's **Date Table** (required for
`TOTALYTD`/`TOTALQTD`/`SAMEPERIODLASTYEAR` DAX time-intelligence to work).

## 5. DAX Measures (`/DAX_Measures/DAX_Measures.txt`)

Includes `Total Sales`, `YTD Sales`, `QTD Sales`, `Sales YoY %`,
`% of Total Sales by Category`, `Rank Branch by Sales`, `Running Total Sales`,
and a data-quality sanity check measure (`Missing Price Rows`) that proves the
Power Query cleanup worked — it always evaluates to `0`.

## 6. Proof of Concept — Cleaned Output (`/Cleaned_Output`)

Since the transformation logic is deterministic, `simulate_etl.py` replicates
the exact same steps in pandas to produce
`Fact_Sales_Consolidated.xlsx` (541 rows) as a verifiable "expected result" —
useful for testing that the real Power Query output matches:

- **541** clean transaction rows from 4 mismatched sources
- **0** missing `UnitPrice` values after cleanup (down from ~15% in Islamabad)
- **0** blank spacer rows remaining
- All 4 branches on one consistent 8-column schema

## 7. Final Power BI Dashboard

Built in Power BI Desktop from the queries and measures above.
The `.pbix` file is included in this repo (`Multi_Branch_Sales_Consolidation.pbix`).

![Dashboard screenshot](Docs/dashboard_screenshot.png)

**KPIs:** Total Sales, YTD Sales | **Branch comparison:** Peshawar leads at
$9.6M, followed by Karachi ($5.0M), Lahore ($3.2M), and Islamabad ($2.8M) |
**Monthly trend:** consolidated sales across all 4 branches by month.

## 8. How to Reproduce This Project

1. Clone this repo and open Power BI Desktop.
2. Paste `01_Master_Query_CombineAllBranches.pq` into a new blank query via
   the Advanced Editor; update `Source_Folder` to point at `/Source_Data`.
3. Repeat for `02_Dim_Date.pq` and `03_Dim_Product.pq`.
4. In **Model view**, build the relationships shown in the schema diagram
   above (1-to-many, single direction, from each Dim to the Fact).
5. Mark `Dim_Date` as the official Date Table (Table tools → Mark as Date Table).
6. Paste the DAX measures from `/DAX_Measures/DAX_Measures.txt`.
7. Build visuals: monthly trend line, branch comparison bar chart, category
   breakdown table, YTD/QTD KPI cards.
8. Save as `.pbix` and publish to Power BI Service.

## 9. Skills Demonstrated

- Power Query (M language): custom functions, conditional columns, unpivot,
  merge/append, data-quality cleanup
- Star-schema data modeling
- DAX time intelligence (YTD, QTD, YoY)
- ETL thinking — designing a pipeline that's resilient to inconsistent source
  formats, a core "data warehousing concepts" skill

---
*Companion project: [Amazon Products Sales Dashboard](../) — covers core
dashboard design, KPI cards, and YTD/QTD DAX on a single clean dataset.*
